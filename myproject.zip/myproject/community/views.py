from django.shortcuts import render
from .models import Post, Comment
import json
from django.http import JsonResponse

# Create your views here.
def overseas(request):
    posts = Post.objects.filter(type=0)
    
    context ={
        'posts': posts
    }
    return render(request, 'community/overseas.html', context=context)

def domestic(request):
    context ={

    }
    return render(request, 'community/domestic.html', context=context)

def write(request):
    return render(request, 'community/writepost.html')
    
def check(request):
    if request.method == "POST":
        print(request.POST)
        print(request.POST['content'])
    return render(request, 'community/check.html')

def post(request, id):
    post = Post.objects.filter(id=id).first()
    comments = Comment.objects.filter(post=id, parent_comment=None).order_by("timestamp")
    print(comments)



    context ={
        'post': post,
        'comments':comments
    }
    return render(request, 'community/post.html', context=context)

def likeit(request):
    post_id = request.GET.get('postid')
    post = Post.objects.filter(id=post_id).first()
    if post.likes.filter(pk=request.user.id).exists():
        post.likes.remove(request.user)
        post.save()   
    else:
        post.likes.add(request.user)
        post.save()
    like_num = len(post.likes.all())
    response_data = {
        'post_id': post_id,
        'like_num':like_num
    }
    return JsonResponse(response_data)